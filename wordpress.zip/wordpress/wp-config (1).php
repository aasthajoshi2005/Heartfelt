<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'if0_38143617_wp101' );

/** Database username */
define( 'DB_USER', '38143617_3' );

/** Database password */
define( 'DB_PASSWORD', '2)pSM8!24k' );

/** Database hostname */
define( 'DB_HOST', 'sql300.byetcluster.com' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '4krah1fmglncan5mfzfqtwf2nydi9t6udetkdpinpc1bw0m5wttb69007i4iti1g' );
define( 'SECURE_AUTH_KEY',  'wyp5w4oehdbglcrrqgpq2zdvjprhzskucn0jywqmv9rujpmnyyaiyxczeo5ugyan' );
define( 'LOGGED_IN_KEY',    'cetkeove2vlcmnkaxadgrpif7a0xh5kugbjzutpxb8mwytkktodqr5u0gk9s48tm' );
define( 'NONCE_KEY',        'z9txadnz9q0tfjxuwbjfupomjoqigua1nsfiau1snwopbxkf81heahiyc1mkxbby' );
define( 'AUTH_SALT',        'igjplmvtjkkv2qsy2bkv0ejic7xclekrivehcxdawt4fafht1lyctfa8rukuhzxj' );
define( 'SECURE_AUTH_SALT', 'twn86yzh3hqrqkg05htxtcpobhjl7l2p1tridabladqjr2p2le24s9glkp6s9djs' );
define( 'LOGGED_IN_SALT',   'kypcqovscsaewxwengxt7goedzw9mvhh9glbiyotyu6qcds4isxx4i1y23wwvtwq' );
define( 'NONCE_SALT',       'lqevkmujp5dqyo8dgfmhhksjcvp751qjzictwjtp8edlwakyq9ma6zmwua8qs9ca' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wpke_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
